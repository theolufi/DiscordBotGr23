const { Client, Collection, GatewayIntentBits, Events } = require("discord.js");
const { token } = require("./config.json");
const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");

// client instanz
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessages,
  ],
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands/test");
const commandFiles = fs
  .readdirSync(commandsPath)
  .filter((file) => file.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

// wetter import
const weatherCommand = require("./commands/test/weather");
client.commands.set(weatherCommand.data.name, weatherCommand);

// check ob logged in
client.once(Events.ClientReady, () => {
  console.log(`Ready! Logged in as ${client.user.tag}`);
});

// InteractionCreate
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    return await interaction.reply({
      content: `${interaction.commandName} is not a valid command. Type "/" to see all working commands :)`,
      ephemeral: true,
    });
  }

  try {
    if (command === weatherCommand) {
      await command.execute(interaction);
    } else {
      await command.execute(interaction);
    }
  } catch (error) {
    console.error(error);
    await interaction.reply({
      content: ":x: There was an error while executing this command :x:",
      ephemeral: true,
    });
  }
});

// MessageCreate
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  if (message.content.toUpperCase() === "HI") {
    const channel = await client.channels.fetch("1100840732320862312");
    channel.send(`Hey ${message.author.username}!`);
  } else if (message.content.toUpperCase() === "IM BORED") {
    const channel = await client.channels.fetch("1100840732320862312");
    channel.send("You might want to watch this if you're seriously bored: https://youtu.be/LKPwKFigF8U");
  } else if (message.content.toUpperCase().startsWith("CURRENCY")) {
    const args = message.content.split(" ");
    if (args.length !== 3) {
      message.reply("Please enter a base and target currency :money_with_wings:");
      return;
    }
    const baseCurrency = args[1].toUpperCase();
    const targetCurrency = args[2].toUpperCase();
    try {
      const rate = await fetchExchangeRate(baseCurrency, targetCurrency);
      const conversionMessage = `1 ${baseCurrency} = ${rate} ${targetCurrency}`;
      message.reply(conversionMessage);
    } catch (error) {
      console.error(error);
      message.reply("Failed to fetch an exchange rate :(");
    }
  }
});

// exchange rate api
async function fetchExchangeRate(baseCurrency, targetCurrency) {
  const url = `https://v6.exchangerate-api.com/v6/16b009830722e7e230f41f10/latest/${baseCurrency}`;
  const response = await fetch(url);
  const data = await response.json();
  const rate = data.conversion_rates[targetCurrency];
  return rate.toFixed(2);
}

// quote fetcher
async function fetchQuote() {
  const response = await fetch("https://api.quotable.io/random");
  const quoteData = await response.json();
  const quote = `${quoteData.content}\n\n- ${quoteData.author}`;
  return quote;
}

// dc client token login
client.login(token);
