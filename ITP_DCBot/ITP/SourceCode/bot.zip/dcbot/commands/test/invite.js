const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("invite")
    .setDescription("Generate an invite link for your homies!"),
  async execute(interaction) {
    const guildId = interaction.guild.id;
    const inviteLink = `https://discord.com/oauth2/authorize?client_id=${interaction.client.user.id}&scope=bot&permissions=8&guild_id=${guildId}`;
    await interaction.reply(`Send this to a friend who you'd love to see in here :arrow_right: ${inviteLink} :arrow_left:`);
  },
};
