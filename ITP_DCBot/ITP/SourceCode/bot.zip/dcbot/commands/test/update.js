const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("update")
    .setDescription("Adds Video to Watch2Gether lobby!")
    .addStringOption((option) =>
      option
        .setName("lobby")
        .setDescription("Enter W2G Lobby URL here")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("video")
        .setDescription("Enter Video URL here")
        .setRequired(true)
    ),
  async execute(interaction) {
    const lobby = interaction.options.getString("lobby");
    const url = interaction.options.getString("video");

    const ytRegex =
      /^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$/;
    if (!ytRegex.test(url)) {
      return await interaction.reply({
        content:
          "Please provide a valid YouTube URL so we can start this party!",
        ephemeral: true,
      });
    }

    console.log(lobby);

    await interaction.deferReply();

    fetch(
      "https://api.w2g.tv/rooms/" +
        lobby +
        "/playlists/current/playlist_items/sync_update",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          w2g_api_key:
            "jr26tfmqwhefbsm4hcgpw5hrw1u2m4y4ntrz4vux1i606kd1a3x19ap0zyjat3gy",
          add_items: [
            {
              url: url,
              title: "Next Video",
            },
          ],
        }),
      }
    );

    await interaction.editReply("Room successfully updated!");
  },
};
