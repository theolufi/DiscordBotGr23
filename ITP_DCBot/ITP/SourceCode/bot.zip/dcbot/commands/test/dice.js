const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("dice")
    .setDescription("Rolls a dice for you"),
  async execute(interaction) {
    const rdm = Math.floor(Math.random() * 6);
    let dice;

    switch (rdm) {
      case 0:
        dice = 1;
        break;
      case 1:
        dice = 2;
        break;
      case 2:
        dice = 3;
        break;
      case 3:
        dice = 4;
        break;
      case 4:
        dice = 5;
        break;
      case 5:
        dice = 6;
        break;
    }

    await interaction.reply(`It's a ${dice}!`);
  },
};
