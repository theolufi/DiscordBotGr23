const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("server")
    .setDescription("Server name & Member count"),
  async execute(interaction) {
    await interaction.reply(
      `This servers name is ${interaction.guild.name} and it currently has ${interaction.guild.memberCount} members! :chart_with_upwards_trend: `
    );
  },
};
