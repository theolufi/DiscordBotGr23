const { SlashCommandBuilder } = require("discord.js");
const fetch = require("node-fetch");

const newsAPIKey = "73343312a2e148bebf27376339427460";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("news")
    .setDescription("News information")
    .addStringOption((option) =>
      option
        .setName("location")
        .setDescription("Location (/news-locations for available countries)")
        .setRequired(true)
    ),
  async execute(interaction) {
    const location = interaction.options.getString("location");
    let response = "";

    try {
      const newsData = await fetchNewsData(location);

      newsData.articles.map((article) => {
        response += `Title: ${article.title}\nNews Url: ${article.url}\n\n`;
      });

      if (response.length <= 2000) {
        await interaction.reply(response);
      } else {
        const chunks = splitResponseIntoChunks(response, 2000);
        for (const chunk of chunks) {
          await interaction.channel.send(chunk);
        }
      }
    } catch (error) {
      console.error(error);
      await interaction.reply(
        "Failed to fetch news data for this location :( Try again!"
      );
    }
  },
};

async function fetchNewsData(location) {
  const url =
    "https://newsapi.org/v2/top-headlines?" +
    "country=" +
    location +
    "&apiKey=" +
    newsAPIKey;

  const response = await fetch(url);
  const data = await response.json();
  return data;
}

function splitResponseIntoChunks(response, chunkSize) {
  const chunks = [];
  let i = 0;

  while (i < response.length) {
    chunks.push(response.substring(i, i + chunkSize));
    i += chunkSize;
  }

  return chunks;
}
