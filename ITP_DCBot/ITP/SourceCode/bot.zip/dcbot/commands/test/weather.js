const { SlashCommandBuilder } = require("discord.js");
const fetch = require("node-fetch");

const weatherAPIKey = "31d92f5a0a3d4620baf180733232406";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("weather")
    .setDescription("Weather information")
    .addStringOption((option) =>
      option.setName("location").setDescription("Location").setRequired(true)
    ),
  async execute(interaction) {
    const location = interaction.options.getString("location");

    try {
      const weatherData = await fetchWeatherData(location);
      const weatherEmbed = createWeatherEmbed(weatherData);
      await interaction.reply({ embeds: [weatherEmbed] });
    } catch (error) {
      console.error(error);
      await interaction.reply(
        "Failed to fetch weather data for this location :( Try again!"
      );
    }
  },
};

async function fetchWeatherData(location) {
  const url = `http://api.weatherapi.com/v1/current.json?key=${weatherAPIKey}&q=${encodeURIComponent(
    location
  )}&aqi=no`;
  const response = await fetch(url);
  const data = await response.json();
  return data;
}

function createWeatherEmbed(weatherData) {
  const { location, current } = weatherData;

  const weatherEmbed = {
    color: 0x3498db,
    title: `Weather in ${location.name}, ${location.country}`,
    description: `Temperature: ${current.temp_c}°C\nCondition: ${current.condition.text}`,
    timestamp: new Date(),
  };

  return weatherEmbed;
}
