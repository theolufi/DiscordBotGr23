const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rps")
    .setDescription("Play Rock-Paper-Scissors against the bot!")
    .addStringOption((option) =>
      option
        .setName("choice")
        .setDescription("Enter Rock/Paper/Scissors!")
        .setRequired(true)
    ),
  async execute(interaction) {
    const playerChoice = interaction.options.getString("choice");

    if (
      playerChoice.toUpperCase() != "ROCK" &&
      playerChoice.toUpperCase() != "PAPER" &&
      playerChoice.toUpperCase() != "SCISSORS"
    ) {
      await interaction.reply(
        "Please enter a valid option! Rock/Paper/Scissors"
      );
    } else {
      const rdm = Math.floor(Math.random() * 3);
      let botChoice;

      switch (rdm) {
        case 0:
          botChoice = "Rock";
          break;
        case 1:
          botChoice = "Scissors";
          break;
        case 2:
          botChoice = "Paper";
          break;
      }

      if (
        (playerChoice.toUpperCase() == "ROCK" && rdm == 1) ||
        (playerChoice.toUpperCase() == "PAPER" && rdm == 0) ||
        (playerChoice.toUpperCase() == "SCISSORS" && rdm == 2)
      ) {
        await interaction.reply(
          `${interaction.user.username} played ${playerChoice} into the bot's ${botChoice}. ${interaction.user.username} wins!`
        );
      } else if (
        (playerChoice.toUpperCase() == "ROCK" && rdm == 2) ||
        (playerChoice.toUpperCase() == "PAPER" && rdm == 1) ||
        (playerChoice.toUpperCase() == "SCISSORS" && rdm == 0)
      ) {
        await interaction.reply(
          `${interaction.user.username} played ${playerChoice} into the bot's ${botChoice}. ${interaction.user.username} loses!`
        );
      } else {
        await interaction.reply(
          `${interaction.user.username} played ${playerChoice} into the bot's ${botChoice}. It's a draw!`
        );
      }
    }
  },
};
