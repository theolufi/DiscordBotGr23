const { SlashCommandBuilder } = require('@discordjs/builders');
const { createAudioResource, createAudioPlayer, joinVoiceChannel, StreamType, AudioPlayerStatus } = require('@discordjs/voice');
const ytdl = require('ytdl-core');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Plays a YouTube videos audio')
    .addStringOption(option =>
      option.setName('url')
        .setDescription('Enter URL here')
        .setRequired(true)
    ),
  async execute(interaction) {
    const url = interaction.options.getString('url');

    // valide yt url oder nicht - Error in RegEx - troubleshoot + tests ?
    const ytRegex = /^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$/;
    if (!ytRegex.test(url)) {
      return await interaction.reply({ content: 'Please provide a valid YouTube URL so we can start this party!', ephemeral: true });
    }

    const channel = interaction.member?.voice.channel;
    if (!channel) {
      return await interaction.reply({ content: 'You need to join a voice channel first in order to use this command', ephemeral: true });
    }

    const connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator,
    });

    const stream = ytdl(url, { filter: 'audioonly', quality: 'highestaudio' });

    const resource = createAudioResource(stream, { inputType: StreamType.Arbitrary });

    const player = createAudioPlayer();

    player.play(resource);
    connection.subscribe(player);

    player.on('error', error => {
      console.error(resource);
      interaction.followUp({ content: 'An error occurred while playing the song :(', ephemeral: true });
    });
    player.on(AudioPlayerStatus.Idle, () => {
      player.stop();
      connection.destroy();
    });

    await interaction.reply({ content: 'I joined your channel and am playing your song now! Beep Boop :robot:', ephemeral: true });
  },
};
